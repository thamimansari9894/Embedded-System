#include<pic.h>
#define C1 RB0
#define C2 RB1
#define C3 RB2
#define R1 RB4
#define R2 RB5
#define R3 RB6
#define R4 RB7
#define RS RC0
#define RW RC1
#define EN RC2
void cmd(unsigned char a);
void dat(unsigned char a);
void delay();
void RF1();
void RF2();
void RF3();
void main(){
PORTB=0x00;
PORTC=0x00;
PORTD=0x00;
TRISB=0xF0;
TRISC=0x00;
TRISD=0x00;
cmd(0x38);
cmd(0x0C);
cmd(0x10);
cmd(0x01);
cmd(0x06);
cmd(0x80);
cmd(0xC0);
while(1){
	R1=R2=R3=R4=0;
	C1=1;
	if(R1==1){
	dat('1');
	}
	if(R2==1){
	dat('4');
	}
	if(R3==1){
	dat('7');
	}
	if(R4==1){
	dat('*');
	}
	R1=R2=R3=R4=0;
    C2=1;
	if(R1==1){
	dat('2');
	}
	if(R2==1){
	dat('5');
	}
	if(R3==1){
	dat('8');
	}
	if(R4==1){
	dat('0');
	}
	R1=R2=R3=R4=0;
	C3=1;
	if(R1==1){
	dat('3');
	}
	if(R2==1){
	dat('6');
	}
	if(R3==1){
	dat('9');
	}
	if(R4==1){
	dat('#');}}}
	void cmd(unsigned char a){
	PORTD=a;
	RS=0;
	RW=0;
	EN=1;
	delay();
	EN=0;}
void dat(unsigned char a){
	PORTD=a;
	RS=1;
	RW=0;
	EN=1;
	delay();
	EN=0;}
void delay(){
	unsigned int i;
	for(i=0;i<10000;i++);}